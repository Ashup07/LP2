import java.util.*;

public class selectionSort{                 //Time complexity of Selection Sort : O(n^2)
    public static void Sort(int array[]){
        System.out.print("Array after Selection Sort: ");
        for(int i = 0; i<array.length; i++){
            for(int j = i; j<array.length; j++){
                if(array[i] > array[j]){
                    int temp = array[i];
                    array[i] = array[j];
                    array[j] = temp;
                }
            }  System.out.print(array[i] + " ");  
        }
    }
    public static void main(String args[]){
        Scanner sc = new Scanner(System.in);
        System.out.println("____Selection Sort____");
        // int arr[] = {12,5,32,45,11,20,8};
        // Sort(arr);

        int num;
        int elements;
        System.out.print("Enter total number of elements: ");
        num = sc.nextInt();
        int[] arr = new int[num];
        System.out.println("Enter elements: ");
        for(int i=0; i<num; i++){
            elements = sc.nextInt();
            arr[i] = elements;
        }
        Sort(arr);     
    }
}