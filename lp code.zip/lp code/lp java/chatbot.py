class CollegeAdmissionChatbot:
    def __init__(self):
        self.responses = {
            'hello': 'Hello! How can I assist you with college admission?',
            'bye': 'Goodbye! Have a great day!',
            'courses': '\n Computer\n IT\n Electrical\n Civil\n EnTC',
            'application deadline': 'The application deadline for our college is July 15th.',
            'admission criteria': 'Our admission criteria include- \n academic performance,\n extracurricular activities,\n recommendation letters.',
            'fee structure': 'Fee structure is as follows \n tution fees is Rs 64000\n+ management fees is Rs 10000\n+ Library fees is Rs 5000 \n+ Course fees is Rs 45000 \n Total fees is Rs 134000' ,
            'virtual tour': 'You can take a virtual tour of our campus on our website.',
        }

    def get_response(self, user_input):
        user_input = user_input.lower()
        return self.responses.get(user_input, "I'm sorry, I didn't understand that.")

    def start_chatting(self):
        print("College Admission Chatbot: Type 'bye' to exit.")
        while True:
            user_input = input("You: ")
            if user_input.lower() == 'bye':
                print("College Admission Chatbot: Goodbye!")
                break
            response = self.get_response(user_input)
            print(f"College Admission Chatbot: {response}")


if __name__ == "__main__":
    chatbot = CollegeAdmissionChatbot()
    print('sugessions to chat : \n hello\n courses\n application deadline\n admission criteria\n fee structure\n virtual tour\n bye')
    chatbot.start_chatting()
